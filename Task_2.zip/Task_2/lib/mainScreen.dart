// ignore_for_file: file_names

import 'package:flutter/material.dart';


class Mainscreen extends StatefulWidget {
  const Mainscreen({super.key});

  @override
  State<Mainscreen> createState() => _MainscreenState();
}

class _MainscreenState extends State<Mainscreen> {

  bool visible = false;
  final List<GlobalKey<FormState>> keys = List.generate(4, (index) => GlobalKey<FormState>());

  final List<TextEditingController> controllers = List.generate(4, (index) => TextEditingController());

  @override
  void dispose() {
    super.dispose();
    controllers[0].dispose();
    controllers[1].dispose();
    controllers[2].dispose();
    controllers[3].dispose();
  }  

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.only(left: 20, right: 20, top: 29),
        child: CustomScrollView(
          slivers: [
            const SliverToBoxAdapter(child: SizedBox(height: 30)),
            SliverToBoxAdapter(child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                IconButton(onPressed: (){}, icon: const Icon(Icons.keyboard_backspace_rounded)),
                IconButton(onPressed: (){}, icon: const Icon(Icons.settings)),
            ],)),
            const SliverToBoxAdapter(child: SizedBox(height: 20)),
            SliverToBoxAdapter(
              child: Center(
                  child: Column(
                    children: [
                      Stack(
                        alignment: Alignment.bottomRight, 
                        children: [
                          Container(
                            width: 139,
                            height: 139,
                            decoration: BoxDecoration(
                              border: Border.all(color: Colors.black, width: 0.09),
                              // color: Colors.black,
                              shape: BoxShape.circle,
                              image: const DecorationImage(
                                image: AssetImage('assets/images/default.jpg'), 
                                fit: BoxFit.cover,
                              )
                          ),
                        ),
                        GestureDetector(
                          onTap: () {},
                          child: Container(
                            width: 30,
                            height: 30,
                            decoration: const BoxDecoration(
                                color: Color(0xffEE8924) ,
                                shape: BoxShape.circle,
                                ),
                            child: const Icon(Icons.edit_outlined, color: Colors.white,),
                          ),
                        ),
                      ]),
                      const SizedBox(height: 15,),
                      const Text('GFXAgency', style: TextStyle(color: Color(0xff262422), fontWeight: FontWeight.w600, fontSize: 20),),
                      const Text('UI UX DESIGN', style: TextStyle(color: Color(0xffABABAB), fontWeight: FontWeight.w400, fontSize: 14),),
                    ],
                  ),
                ),
            ),
            const SliverToBoxAdapter(child: SizedBox(height: 12)),
            SliverToBoxAdapter(child: customForm(keys[0], controllers[0], 'xxx@gmail.com', 'Your Email', TextInputType.emailAddress, fieldType: 'email' ,icon:  const Icon(Icons.email_outlined, size: 24, color: Color(0xffABABAB)))),
            SliverToBoxAdapter(child: customForm(keys[1], controllers[1], '+93123135', 'Phone Number', TextInputType.phone , fieldType: 'phone' ,icon: const Icon(Icons.phone_outlined, size: 24, color: Color(0xffABABAB)))),
            SliverToBoxAdapter(child: customForm(keys[2], controllers[2], 'www.gfx.com', 'Website', TextInputType.url, fieldType: 'website')),
            SliverToBoxAdapter(child: customForm(keys[3], controllers[3], 'xxxxxxxx', 'Password', TextInputType.text, icon: const Icon(Icons.lock_outline, size: 24, color: Color(0xffABABAB)), eyeIcon: true, password: true)),
            const SliverToBoxAdapter(child: SizedBox(height: 34)),
            SliverToBoxAdapter(child: 
            GestureDetector(
              onTap: () {
                if (keys.every((key) => key.currentState!.validate())) {
                  FocusScope.of(context).unfocus();
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Done !'),
                      backgroundColor: Color(0xffEE8924),
                    ),
                  );
                  setState(() {
                    controllers[0].clear();
                    controllers[1].clear();
                    controllers[2].clear();
                    controllers[3].clear();
                  });
                }
              },
              child: Container(
                height: 58,
                decoration: BoxDecoration(border: Border.all(color: const Color(0xffEE8924), width: 1), borderRadius: BorderRadius.circular(12)),
                child: const Center(child: Text('Login', style: TextStyle(fontSize: 16, color: Color(0xffEE8924), fontWeight: FontWeight.w700),),),
              ),
            )),
            const SliverToBoxAdapter(child: SizedBox(height: 30)),
          ],
        ),
      ),
    );
  }


  Widget customForm(GlobalKey<FormState> key, TextEditingController controller, String hint , String fieldName, TextInputType? keyboardType ,{Widget? icon , bool? eyeIcon , bool? password , String? fieldType }) {
  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      const SizedBox(height: 20),
      Text(fieldName ,style: const TextStyle(color: Color(0xff262422), fontWeight: FontWeight.w600, fontSize: 14),),
      const SizedBox(height: 10,),
      Form(
          key: key,
          child: TextFormField(
            obscureText: password == true ? !visible : false,
            obscuringCharacter: '*',
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.black,),
            decoration: InputDecoration(
              contentPadding: const EdgeInsets.symmetric(vertical: 15 , horizontal: 16),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(color: Color(0xffABABAB), width: 1),
            ),
            hintText: hint,
            prefixIcon: icon != null ? icon : null,
            suffixIcon: eyeIcon == true ? IconButton(
              onPressed: (){
                setState(() {
                  visible = !visible;
                });
              },
              icon: !visible ? const Icon(Icons.visibility_outlined, size: 24, color: Color(0xffABABAB)): const Icon(Icons.visibility_off_outlined, size: 24, color: Color(0xffABABAB))) : null,
            hintStyle: const TextStyle(color: Color(0xffABABAB) ,fontWeight: FontWeight.w500),
                enabledBorder: const OutlineInputBorder(
                  borderSide: BorderSide(color: Color(0xffF1ECEC), width: 1),
                  borderRadius: BorderRadius.all(Radius.circular(12))
                )
            ),
            keyboardType: keyboardType,
            controller: controller,
            validator: (value) {
              if (value!.isEmpty) {
                return "This field is required";
              }

              if (fieldType == "phone" && !RegExp(r'^\+?[0-9]{11,12}$').hasMatch(value)) {
                return "Enter a valid phone number";
              }

              if (fieldType == "email" && !RegExp(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$').hasMatch(value)) {
                return "Enter a valid email";
              }

              if (fieldType == "website" && !RegExp(r'^(https?:\/\/)?(www\.)?[a-zA-Z0-9-]+\.[a-zA-Z]{2,}(\/\S*)?$').hasMatch(value)) {
                return "Enter a valid website";
              }

              return null;
            },
          )),
    ],
  );
}
}